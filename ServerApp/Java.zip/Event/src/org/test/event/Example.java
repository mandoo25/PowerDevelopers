package org.test.event;

public class Example {
	public static void main(String[] args) {
		ListenerA listenerA = new ListenerA();
		ListenerB listenerB = new ListenerB();
		
		EventHandler.callEvent(Example.class, "EVENT_A", false); // ���� ȣ��
		System.out.println("After introduce ListenerA");
		EventHandler.callEvent(Example.class, "EVENT_B"); // �񵿱� ȣ��
	}
}
