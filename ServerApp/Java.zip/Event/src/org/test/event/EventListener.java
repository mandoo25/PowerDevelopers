package org.test.event;

public interface EventListener {
	public void onEvent(String event);
}
