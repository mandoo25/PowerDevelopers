package org.collector.event;

public interface EventListener {
	public void onEvent(String event);
}
