package com.collector.method;

public interface CollectMethod {
	public boolean trigger();
}
