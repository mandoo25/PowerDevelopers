package com.collector.method;

public class BarcodeMethod implements CollectMethod {
	
	@Override
	public boolean trigger() {
		// TODO Auto-generated method stub
		return false;
	}

}
