package com.collector.method;

public class DistanceMethod implements CollectMethod {

	@Override
	public boolean trigger() {
		// TODO Auto-generated method stub
		return false;
	}

}
