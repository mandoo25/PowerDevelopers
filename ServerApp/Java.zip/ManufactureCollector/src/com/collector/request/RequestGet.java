package com.collector.request;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class RequestGet {
	private String serverUrl = null;
	private ArrayList<ReqGetParam> reqGetParamList = new ArrayList<ReqGetParam>();

	public void setServerUrl(String url) {
		this.serverUrl = url;
		reqGetParamList.clear();
	}

	public void setParam(String string, String string2) {
		reqGetParamList.add(new ReqGetParam());
		reqGetParamList.get(reqGetParamList.size()-1).setParam(string);
		reqGetParamList.get(reqGetParamList.size()-1).setVal(string2);
	}

	public void run() throws IOException {
		try {
			if(this.serverUrl != null) {
				StringBuilder urlBuilder = new StringBuilder(this.serverUrl); /*URL*/
				
				if(reqGetParamList.size() > 0) {
					urlBuilder.append("?" + URLEncoder.encode(reqGetParamList.get(0).getParam(),"UTF-8") + "=" + URLEncoder.encode(reqGetParamList.get(0).getVal(), "UTF-8"));
					
					for(int i=1; i<reqGetParamList.size(); i++) {
						urlBuilder.append("&" + URLEncoder.encode(reqGetParamList.get(i).getParam(),"UTF-8") + "=" + URLEncoder.encode(reqGetParamList.get(i).getVal(), "UTF-8"));
					}
				}
				
				URL url = new URL(urlBuilder.toString());
		        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		        conn.setRequestMethod("GET");
		        conn.setRequestProperty("Content-type", "application/text");
		        System.out.println("Response code: " + conn.getResponseCode());
		        
		        BufferedReader rd;
		        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
		        	rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		        }
		        else {
		        	rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		        }
		        
		        StringBuilder sb = new StringBuilder();
	            String line;
	            while ((line = rd.readLine()) != null) {
	                sb.append(line);
	            }
	            rd.close();
	            System.out.println(sb.toString());
		        	
		        conn.disconnect();
		        this.serverUrl = null;
		        reqGetParamList.clear();
			}
			else {
				//exception 발생추가
				this.serverUrl = null;
				reqGetParamList.clear();
			}
		} finally {
			this.serverUrl = null;
			reqGetParamList.clear();
		}
	}
}
