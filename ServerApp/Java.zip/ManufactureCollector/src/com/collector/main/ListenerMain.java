package com.collector.main;

import java.io.IOException;
import org.collector.event.*;
import com.collector.request.*;

public class ListenerMain implements EventListener, Define {

	public ListenerMain() {
		EventHandler.addListener(this);		
	}
	
	@Override
	public void onEvent(String event) {
		if (event.equals("EVENT_A")) {
			// do something here for EVENT_A event.
			System.out.println("Barcode !");
			
			RequestGet requestGet = new RequestGet();
			
			requestGet.setServerUrl(SERVER_URL);
			requestGet.setParam("CELL_NAME", event);
			requestGet.setParam("VAL", VAL);
			
			try {
				requestGet.run();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}


