package com.collector.main;

public interface Define {	
	final static String VAL = "START";
	final static String SERVER_URL = "http://localhost:10001";
}
