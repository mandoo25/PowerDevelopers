package com.collector.main;

import org.collector.event.*;

import com.collector.method.*;

public class BarcodeThread extends BarcodeMethod implements Runnable, Define {

	@Override
	public void run() {
		System.out.println("Barcode Thread Start");
		
		EventHandler.callEvent(BarcodeThread.class, "EVENT_A", false);
	}

}
