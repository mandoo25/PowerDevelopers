package com.collector.main;

import java.io.IOException;

import com.collector.method.*;
import com.collector.request.*;

public class CollectorMain {
	private final static String CELL_NAME = "TEST_CELL";
	
	public static void main(String[] args) {
		ListenerMain listenerMain = new ListenerMain();
		
		Runnable runnableBarcodeThread = new BarcodeThread();
		Runnable runnableButtonThread = new ButtonThread();
		
		Thread BarcodeThread = new Thread(runnableBarcodeThread);
		Thread ButtonThread = new Thread(runnableButtonThread);

		BarcodeThread.start();
		ButtonThread.start();
		/*
		RequestGet requestGet = new RequestGet();
		CollectMethod collector = new BarcodeMethod();
		
		while(true)
		{
			if(collector.trigger() == true)
			{
				requestGet.setServerUrl(SERVER_URL);
				requestGet.setParam("CELL_NAME", CELL_NAME);
				requestGet.setParam("VAL", VAL);
				
				try {
					requestGet.run();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}*/
		
				
	}

}
