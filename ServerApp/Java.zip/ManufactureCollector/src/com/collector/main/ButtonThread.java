package com.collector.main;

import com.collector.method.*;

public class ButtonThread extends ButtonMethod implements Runnable{

	@Override
	public void run() {
		System.out.println("Button Thread Start");
	}

}
